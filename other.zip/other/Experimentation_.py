
import numpy as np,cv2,matplotlib.pyplot as plt,pandas as pd,torch
from sklearn.metrics import jaccard_score,accuracy_score
rn=0
from other.train_unet_model import  *
from mod_segnet import improved_segnet,segnet_c


def msk(x):
    gray = cv2.cvtColor(x, cv2.COLOR_RGB2GRAY)
    ret4, th4 = cv2.threshold(gray,100, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return th4

def clahe_preprocess(image, clip_limit=2.0, tile_grid_size=(8, 8, 8)):
    """
    Applies CLAHE (Contrast Limited Adaptive Histogram Equalization) to a 3D image.

    Args:
        image: A 3D NumPy array representing the image.  Should be of type uint8 or float32.
        clip_limit: Clipping limit for CLAHE. Higher values allow more contrast enhancement.
        tile_grid_size: Size of the grid for CLAHE.  Should be a tuple of 3 integers.

    Returns:
        The CLAHE-enhanced 3D image (NumPy array).  Will have the same type as the input.
        If the input is a SimpleITK image, it will return a SimpleITK image.
    """

    clahe = cv2.createCLAHE(clipLimit=3., tileGridSize=(8, 8))
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)  # convert from BGR to LAB color space
    l, a, b = cv2.split(lab)  # split on 3 different channels
    l2 = clahe.apply(l)  # apply CLAHE to the L-channel
    lab = cv2.merge((l2, a, b))  # merge channels
    clahe_image = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
    return clahe_image

def birch_segmentation(pp_im):
    from sklearn.cluster import Birch
    try:
        gray = cv2.cvtColor(pp_im, cv2.COLOR_RGB2GRAY)
    except:
        gray = pp_im
    im = gray.flatten().reshape(-1, 1)
    im=im.astype('float')
    model = Birch(n_clusters=5,threshold=1e-5,branching_factor=5)
    model.fit(im)
    pred_labels = model.predict(im)
    seg = pred_labels.reshape(pp_im.shape[0], pp_im.shape[1])
    seg = seg.astype('uint8')
    return seg


cv_size=224
db=1
path_hist = np.load('saved data/path_his' + str(db) + '.npy', allow_pickle=True)
val=10
path_fin = np.concatenate((path_hist[2][:val], path_hist[0][:val], path_hist[1][:val], path_hist[3][:val]))

save_to='image_results/'
i1,i2,i3,i4,i5,i6=[],[],[],[],[],[]

mm=0
for ii in range(0,len(path_fin),5):
    impath = path_fin[ii]
    print(ii)
    image = cv2.imread(impath)
    plt.figure(1)
    plt.imshow(image)
    plt.axis('off')
    plt.savefig(save_to +'/'+str(mm) +'_input_image' + '.png', dpi=800)

    pp_im = clahe_preprocess(image)
    plt.figure(2)
    plt.imshow(pp_im)
    plt.axis('off')
    plt.savefig(save_to +'/'+str(mm) +'_preprocessed_image' + '.png', dpi=800)

    gt =msk(image)
    i1.append(gt)
    plt.figure()
    plt.imshow(gt)

    seg_unet = cunet(pp_im)
    seg_unet[seg_unet < np.mean(seg_unet)] = 0
    seg_unet[seg_unet >= np.mean(seg_unet)] = 1
    seg_unet = np.repeat(seg_unet[:, :, np.newaxis], 3, axis=2)
    seg_unet = seg_unet * pp_im

    i2.append(seg_unet)
    plt.figure(3)
    plt.imshow(seg_unet, cmap='gray')
    plt.axis('off')
    plt.savefig(save_to + '/' + str(mm) + '_unet_segmentation' + '.png', dpi=800)

    c_birch = birch_segmentation(pp_im)
    c_birch[c_birch < np.mean(c_birch)] = 0
    c_birch[c_birch >= np.mean(c_birch)] = 1
    c_birch = np.repeat(c_birch[:, :, np.newaxis], 3, axis=2)
    c_birch = c_birch * pp_im
    i3.append(c_birch)
    plt.figure(4)
    plt.imshow(c_birch, cmap='gray')
    plt.axis('off')
    plt.savefig(save_to + '/' + str(mm) + '_birch_segmentation' + '.png', dpi=800)

    from tensorflow.keras.models import load_model
    #
    # im = np.tile(pp_img[:, :, np.newaxis], (1, 1, 1))
    # Segnet segmentation
    pp_im=cv2.resize(pp_im,(cv_size,cv_size))
    ln = 3  # len(np.unique(yyy))  # len(np.unique(label))
    input_shape = (cv_size, cv_size, 3)  # Adjust input shape according to your data
    num_classes = ln  # Adjust based on the number of classes in your segmentation task
    if rn == 1:
        seg_model =segnet_c (input_shape, num_classes)
        # seg_model = improved_segnet(input_shape, num_classes)
        seg_model.summary()
    #
    seg_model = load_model('saved data/seg_model_c.h5')
    seg = seg_model.predict(pp_im[np.newaxis, :, :, :])
    seg_out_c =ModelPredict.predict(pp_im,False)

    # seg_out = np.reshape(seg, (cv_size, cv_size, seg.shape[-1]))
    i4.append(seg_out_c)
    plt.figure(5)
    plt.imshow(seg_out_c, cmap='gray')
    plt.axis('off')
    plt.savefig(save_to + '/' + str(mm) + '_segnet_segmentation' + '.png', dpi=800)

    # Segnet segmentation

    input_shape = (cv_size, cv_size, 3)  # Adjust input shape according to your data
    num_classes = ln  # Adjust based on the number of classes in your segmentation task
    # seg_model = improved_segnet(input_shape, num_classes)
    # seg_model.summary()

    seg_model_p = load_model('saved data/seg_model_p.h5')
    seg = seg_model_p.predict(pp_im[np.newaxis, :, :, :])
    seg_out =ModelPredict.predict(pp_im,True)
    # seg_out = np.reshape(seg, (cv_size, cv_size, seg.shape[-1]))
    # seg = predict_model(seg)
    # c = class_pixels(seg_out)
    # seg_im_p = colorize(c)
    # seg_out = (seg_out * 255).astype('uint8')
    i5.append(seg_out)
    plt.figure(6)
    plt.imshow(seg_out, cmap='gray')
    plt.axis('off')
    plt.savefig(save_to + '/' + str(mm) + '_proposed_segnet' + '.png', dpi=800)


    #
    # from sklearn.cluster import KMeans
    #
    # pp_im=  cv2.cvtColor(pp_im, cv2.COLOR_BGR2GRAY)
    #
    # seg_m = KMeans(3, random_state=0).fit(pp_im.reshape(-1, 1))
    # lab_ = seg_m.labels_
    # seg_ = lab_.reshape(pp_im.shape[0], pp_im.shape[1]).astype('uint8')
    # plt.figure(7)
    # plt.imshow(seg_)
    # plt.show()

    mm+=1
