

USE_CUDA = False
import torch.optim as optim
rn=0
from other.root import *
from other.Confusion_matrix import *
from sklearn.model_selection import train_test_split
from tensorflow.keras import layers,models
import networkx as nx
import numpy as np,math,os
import pandas as pd
import torch,time,tensorflow as tf
import torch.nn as nn
import torch.nn.functional as F
device = torch.device('cuda' if USE_CUDA else 'cpu')
from tensorflow.keras import layers, models, optimizers

########## function ##########


def dcnn_(X_train, Y_train, X_test, Y_test, db):
    # number of classes
    ln = len(set(Y_train.flatten()))
    # reshape for 1D CNN: (samples, timesteps, features)
    cnn_X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
    cnn_X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

    # build 1D CNN
    model = models.Sequential()
    model.add(layers.Conv1D(16, kernel_size=3, padding='valid', input_shape=(cnn_X_train.shape[1], 1), activation='relu'))
    model.add(layers.MaxPooling1D(pool_size=2))
    model.add(layers.Dropout(0.2))

    model.add(layers.Conv1D(32, kernel_size=3, activation='relu'))
    model.add(layers.MaxPooling1D(pool_size=2))
    model.add(layers.Dropout(0.2))

    model.add(layers.Flatten())
    model.add(layers.Dense(ln, activation='softmax'))
    model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    print('\n1D CNN model')
    model.summary()
    # train
    model.fit(cnn_X_train, Y_train, epochs=ep, batch_size=128, verbose=0)
    # predict
    pred = model.predict(cnn_X_test)
    y_pred = array(np.argmax(pred, axis=1),axis=[0,db])
    out, cm = multi_confu_matrix(Y_test, y_pred)
    return out, y_pred, cm[0], cm[1]


def lstm_(X_train, Y_train, X_test, Y_test, db):
    ln = len(set(Y_train.flatten()))
    # fix random seed for reproducibility
    np.random.seed(7)
    # load the dataset but only keep the top n words, zero the rest
    top_words = 5000
    train_X = X_train.reshape(-1, X_train.shape[1], 1)
    test_X = X_test.reshape(-1, X_train.shape[1], 1)
    train_X = train_X.astype('float32')
    test_X = test_X.astype('float32')
    train_X = train_X / train_X.max()
    test_X = test_X / train_X.max()
    Lab = np.concatenate((Y_train, Y_test))
    # Change the labels from categorical to one-hot encoding
    train_Y = tf.keras.utils.to_categorical(Y_train)
    test_Y = tf.keras.utils.to_categorical(Y_test)
    embedding_vecor_length = 32

    # Final evaluation of the model
    model = models.Sequential()
    model.add(layers.LSTM(128, input_shape=(train_X.shape[1], train_X.shape[2])))
    model.add(layers.Dropout(0.2))
    # number of features on the output
    model.add(layers.Dense(ln, activation='sigmoid'))
    model.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])
    model.summary()
    rnn_train = model.fit(train_X, train_Y, batch_size=128, epochs=ep, verbose=0)
    y_predict = array(np.argmax(model.predict(test_X), axis=1), axis=[3, db])
    out, cm = multi_confu_matrix(Y_test, y_predict)
    return out, y_predict, cm[0], cm[1]

def bp1_(X_train, Y_train, X_test, Y_test,db):
    ln = len(set(Y_train.flatten()))
    Lab = np.concatenate((Y_train, Y_test))
    Y_train=Y_train
    cnn_X_train = X_train.reshape((X_train.shape[0], 1, 1, X_train.shape[1]))
    cnn_X_test = X_test.reshape((X_test.shape[0], 1, 1, X_train.shape[1]))
    cnn_X_train = cnn_X_train.astype('float32')
    cnn_X_test = cnn_X_test.astype('float32')
    predict = []
    model = models.Sequential()
    input_shape=cnn_X_train[0].shape

    # TimeDistributed CNN for each timestep
    model.add(layers.TimeDistributed(layers.Conv1D(filters=64, kernel_size=1, activation='relu'), input_shape=input_shape))
    model.add(layers.TimeDistributed(layers.MaxPooling1D(pool_size=1)))
    model.add(layers.TimeDistributed(layers.Flatten()))

    # LSTM layer
    model.add(layers.LSTM(128, return_sequences=False))
    model.add(layers.Dropout(0.5))

    # Output layer
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.Dense(ln, activation='softmax' if ln > 1 else 'linear'))
    # Compile model
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy' if ln > 1 else 'mse',
                  metrics=['accuracy'])
    y_train =  tf.keras.utils.to_categorical(Y_train)
    model.fit(cnn_X_train, y_train, epochs=ep, batch_size=64, verbose=0)
    y_pred = array(np.argmax(model.predict(cnn_X_test), axis=1), axis=[4, db])
    out, cm = multi_confu_matrix(Y_test, y_pred)
    return out, y_pred, cm[0], cm[1]



def bp2_(x_train, y_train, x_test, Y_test, db):
    print("\nHybrid 1D CNN Model (multi-kernel concat style)")
    ln = len(set(y_train.flatten()))

    import xgboost as xgb

    xgb_classifier = xgb.XGBClassifier()
    xgb_classifier.fit(x_train, y_train)
    xgb_predictions = xgb_classifier.predict(x_test)

    # Reshape input for 1D CNN
    x_train = x_train.reshape((x_train.shape[0], x_train.shape[1], 1))
    x_test  = x_test.reshape((x_test.shape[0], x_test.shape[1], 1))
    input_shape_ = (x_train.shape[1], 1)

    # One-hot encode labels
    y_train = tf.keras.utils.to_categorical(y_train)
    y_test  = tf.keras.utils.to_categorical(Y_test)

    # --- Multi-kernel convolution branches ---
    inputs = layers.Input(shape=input_shape_)

    # Branch 1: kernel size 3
    b1 = layers.Conv1D(16, kernel_size=3, activation='swish', padding='same')(inputs)
    b1 = layers.LayerNormalization()(b1)
    b1 = layers.Dropout(0.2)(b1)
    b1 = layers.MaxPooling1D(pool_size=2)(b1)

    # Branch 2: kernel size 5
    b2 = layers.Conv1D(16, kernel_size=5, activation='swish', padding='same')(inputs)
    b2 = layers.LayerNormalization()(b2)
    b2 = layers.Dropout(0.2)(b2)
    b2 = layers.MaxPooling1D(pool_size=2)(b2)

    # Branch 3: kernel size 7
    b3 = layers.Conv1D(16, kernel_size=7, activation='swish', padding='same')(inputs)
    b3 = layers.LayerNormalization()(b3)
    b3 = layers.Dropout(0.2)(b3)
    b3 = layers.MaxPooling1D(pool_size=2)(b3)

    # Concatenate learned features
    concat = layers.Concatenate()([b1, b2, b3])

    # Shared deeper conv layers
    x = layers.Conv1D(32, kernel_size=3, activation='swish', padding='same')(concat)
    x = layers.LayerNormalization()(x)
    x = layers.Dropout(0.3)(x)
    x = layers.MaxPooling1D(pool_size=2)(x)

    # Dense representation
    x = layers.Flatten()(x)
    x = layers.Dense(120, activation='swish')(x)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(84, activation='swish')(x)
    x = layers.Dropout(0.3)(x)

    # Final softmax prediction (instead of XGBoost)
    outputs = layers.Dense(ln, activation='softmax')(x)

    # Build model
    model = models.Model(inputs=inputs, outputs=outputs)

    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    # Train
    model.fit(x_train, y_train, epochs=ep, batch_size=64, validation_split=0.2, verbose=0)

    # Predict
    y_predict = np.argmax(model.predict(x_test), axis=1)
    y_predict = array(y_predict, axis=[0, db])   # your custom wrapper
    out, cm = multi_confu_matrix(Y_test, y_predict)
    return out, y_predict, cm[0], cm[1]


def efficient_net(x_train, y_train, x_test, y_test, db):
    from tensorflow.keras import layers, models
    from tensorflow.keras.optimizers import Adam

    # Reshape for 1D CNN
    x_train = np.array(x_train).reshape((x_train.shape[0], x_train.shape[1], 1)).astype('float32') / 255
    x_test = np.array(x_test).reshape((x_test.shape[0], x_test.shape[1], 1)).astype('float32') / 255
    y_train = np.array(y_train).astype('int')
    y_test = np.array(y_test).astype('int')

    num_classes = len(np.unique(y_train))
    y_train = tf.keras.utils.to_categorical(y_train, num_classes)

    # Define a simplified EfficientNet-like 1D model
    inputs = layers.Input(shape=(x_train.shape[1], 1))
    # Stem
    x = layers.Conv1D(32, 3, strides=2, padding="same", activation="relu")(inputs)
    x = layers.BatchNormalization()(x)
    # MBConv-like blocks (use SeparableConv1D instead of DepthwiseConv1D)
    for filters in [32, 64, 128]:
        x = layers.SeparableConv1D(filters, 3, padding="same", activation="relu")(x)
        x = layers.BatchNormalization()(x)
        x = layers.MaxPooling1D(pool_size=2, padding="same")(x)
    # Head
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)
    model = models.Model(inputs, outputs)
    optimizer = Adam(learning_rate=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-08)
    model.compile(optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"])
    model.summary()
    # Train
    if rn:model.fit(x_train, y_train, batch_size=128, epochs=ep, verbose=0)
    # Predict
    pred = model.predict(x_test)
    y_pred = np.argmax(pred, axis=1)
    # Example confusion matrix call (replace with your own function)
    out, cm = multi_confu_matrix(y_test, y_pred)
    return out, y_pred, cm[0], cm[1]


def lenet_(x_train, y_train, x_test, Y_test, db):
    print("\n LeNet 1D Model")
    ln = len(set(y_train.flatten()))

    # Reshape input for 1D CNN: (samples, timesteps, features)
    # Example: if x_train is (N, 1024), reshape to (N, 1024, 1)
    x_train = x_train.reshape((x_train.shape[0], x_train.shape[1], 1))
    x_test  = x_test.reshape((x_test.shape[0], x_test.shape[1], 1))
    input_shape_ = (x_train.shape[1], 1)

    # One-hot encode labels
    y_train = tf.keras.utils.to_categorical(y_train)
    y_test  = tf.keras.utils.to_categorical(Y_test)

    # Build the 1D LeNet model
    model = models.Sequential()
    # First Conv1D + Pooling
    model.add(layers.Conv1D(16, kernel_size=5, activation='relu', input_shape=input_shape_))
    model.add(layers.MaxPooling1D(pool_size=2))
    # Second Conv1D + Pooling
    model.add(layers.Conv1D(32, kernel_size=5, activation='relu'))
    model.add(layers.MaxPooling1D(pool_size=2))
    # Fully connected layers
    model.add(layers.Flatten())
    model.add(layers.Dense(120, activation='relu'))
    model.add(layers.Dense(84, activation='relu'))
    model.add(layers.Dense(ln, activation='softmax'))

    # Compile
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    # Train
    model.fit(x_train, y_train, epochs=ep, batch_size=64, validation_split=0.2, verbose=0)

    # Predict
    y_predict = np.argmax(model.predict(x_test), axis=1)
    y_predict = array(y_predict, axis=[0, db])   # your custom wrapper
    out, cm = multi_confu_matrix(Y_test, y_predict)

    return out, y_predict, cm[0], cm[1]


def conv_shufflenet_(X_train, Y_train, X_test, Y_test, db):
    # Channel Shuffle for 1D
    def channel_shuffle(x, groups):
        batch_size, length, channels = tf.shape(x)[0], tf.shape(x)[1], x.shape[-1]
        channels_per_group = channels // groups
        x = tf.reshape(x, [batch_size, length, groups, channels_per_group])
        x = tf.transpose(x, [0, 1, 3, 2])
        x = tf.reshape(x, [batch_size, length, channels])
        return x

    # ShuffleNet Unit (Block) for 1D
    def shufflenet_unit(x, out_channels, groups, stride=1):
        shortcut = x
        in_channels = int(x.shape[-1])

        # 1x1 Group Convolution
        group_conv = layers.Conv1D(out_channels // 4, kernel_size=1, use_bias=False)(x)
        group_conv = layers.BatchNormalization()(group_conv)
        group_conv = layers.ReLU()(group_conv)

        # Channel Shuffle
        group_conv = channel_shuffle(group_conv, groups)

        # Depthwise Separable Convolution (1D)
        dw_conv = layers.SeparableConv1D(out_channels, kernel_size=3, strides=stride,
                                         padding='same', use_bias=False)(group_conv)
        dw_conv = layers.BatchNormalization()(dw_conv)

        # Skip connection
        if stride == 1 and in_channels == out_channels:
            output = layers.Add()([shortcut, dw_conv])
        else:
            output = dw_conv

        output = layers.ReLU()(output)
        return output

    # ShuffleNet Model (1D)
    def build_shufflenet(input_shape, num_classes, num_groups=3):
        input_layer = layers.Input(shape=input_shape)

        # Initial Convolution Layer
        x = layers.Conv1D(24, kernel_size=3, strides=2, padding='same', use_bias=False)(input_layer)
        x = layers.BatchNormalization()(x)
        x = layers.ReLU()(x)
        x = layers.MaxPooling1D(pool_size=3, strides=2, padding='same')(x)

        # ShuffleNet Blocks
        x = shufflenet_unit(x, 240, groups=num_groups, stride=2)
        x = shufflenet_unit(x, 480, groups=num_groups, stride=1)
        x = shufflenet_unit(x, 960, groups=num_groups, stride=1)

        # Global Average Pooling
        x = layers.GlobalAveragePooling1D()(x)

        # Fully connected layer
        output_layer = layers.Dense(num_classes, activation='softmax')(x)

        model = models.Model(inputs=input_layer, outputs=output_layer)
        return model

    # Example usage
    input_shape = (X_train.shape[1], 1)
    num_classes = len(set(Y_train.flatten()))

    model = build_shufflenet(input_shape, num_classes, num_groups=3)
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()

    # Reshape data
    x_train = np.expand_dims(X_train, axis=-1)
    x_test = np.expand_dims(X_test, axis=-1)
    y_train_cat = tf.keras.utils.to_categorical(Y_train, num_classes)

    model.fit(x_train, y_train_cat, epochs=ep, batch_size=64, verbose=0)
    y_pred = np.argmax(model.predict(x_test), axis=-1)

    y_pred = array(y_pred, axis=[0, db])
    out, cm = multi_confu_matrix(Y_test, y_pred)
    return out, y_pred, cm[0], cm[1]


def dense_net_(X_train, y_train, X_test, y_test, db):
    Input, compression = 1, 0.1
    n = [0, 1]

    # Reshape for 1D input: (samples, timesteps, channels)
    X_train = np.resize(X_train, (X_train.shape[0], X_train.shape[1], 1))  # example: 1024 timesteps
    X_test = np.resize(X_test, (X_test.shape[0], X_test.shape[1], 1))
    timesteps, channel_size = X_train.shape[1], X_train.shape[2]
    num_classes = len(np.unique(y_train))
    y_train = tf.keras.utils.to_categorical(y_train, num_classes)

    def denseblock(input, num_filter=12, dropout_rate=0.2):
        temp = input
        for _ in range(l):
            BatchNorm = layers.BatchNormalization()(temp)
            relu = layers.Activation('relu')(BatchNorm)

            Conv1D_3 = layers.Conv1D(int(num_filter * compression), 3, use_bias=False, padding='same')(relu)
            if dropout_rate > 0:
                Conv1D_3 = layers.Dropout(dropout_rate)(Conv1D_3)
            concat = layers.Concatenate(axis=-1)([temp, Conv1D_3])
            temp = concat
        return temp

    def transition(input, num_filter=12, dropout_rate=0.2):
        BatchNorm = layers.BatchNormalization()(input)
        relu = layers.Activation('relu')(BatchNorm)
        Conv1D_BottleNeck = layers.Conv1D(int(num_filter * compression), 1, use_bias=False, padding='same')(relu)
        if dropout_rate > 0:
            Conv1D_BottleNeck = layers.Dropout(dropout_rate)(Conv1D_BottleNeck)
        avg = layers.AveragePooling1D(pool_size=2)(Conv1D_BottleNeck)
        return avg

    def output_layer(input):
        BatchNorm = layers.BatchNormalization()(input)
        relu = layers.Activation('relu')(BatchNorm)
        global_average_pooling = layers.GlobalAveragePooling1D()(relu)
        global_max_pooling = layers.GlobalMaxPooling1D()(relu)
        concat_lay = layers.Concatenate(axis=-1)([global_average_pooling, global_max_pooling])
        flat = layers.Flatten()(concat_lay)
        output = layers.Dense(num_classes, activation='softmax')(flat)
        return output

    l = 7
    input = layers.Input(shape=(timesteps, channel_size))
    First_Conv1D = layers.Conv1D(30, 3, use_bias=False, padding='same')(input)

    First_Block = denseblock(First_Conv1D, 30, 0.5)
    First_Transition = transition(First_Block, 30, 0.5)
    Last_Block = denseblock(First_Transition, 30, 0.5)
    output = output_layer(Last_Block)

    model = models.Model(inputs=[input], outputs=[output])
    model.compile(loss='categorical_crossentropy', optimizer='Adam', metrics=['accuracy'])
    # Data augmentation for 1D signals (optional, usually custom)
    # For now, skip ImageDataGenerator since it's 2D-specific

    y_predict = array(np.argmax(model.predict(X_test), axis=-1), axis=[2, db])
    out, cm = multi_confu_matrix(y_test, y_predict)
    return out, y_predict, cm[0], cm[1]

# from sklearn.model_selection import train_test_split
# import numpy as np
# from other.root import *
# from other.Confusion_matrix import *

def load_data(db):
    xx = np.load('saved data/fused_feat' + str(db) + '.npy')
    zz = np.load('saved data/fin_label' + str(db) + '.npy')
    return xx, zz

Read=True
db=1

feat, label = load_data(db)





def metrices_(pred, Y_test):
    out = multi_confu_matrix(Y_test, pred)
    return out


def imp_cnn_lstm(X_train, X_test, Y_train, Y_test, db):
    ln = len(set(Y_train.flatten()))

    def fuzzy_cbam_ss(x):
        high_membership = tf.sigmoid(x)
        low_membership = tf.sigmoid(-x)
        out_fsc = high_membership * x + low_membership * (1 - x)
        out_lrelu = layers.LeakyReLU()(out_fsc)

        # ----- Channel Attention -----
        def channel_attention(x, ratio=8):
            channels = x.shape[-1]
            avg_pool = tf.reduce_mean(x, axis=1, keepdims=True)
            max_pool = tf.reduce_max(x, axis=1, keepdims=True)
            add_out = avg_pool + max_pool

            shared_mlp = tf.keras.Sequential([
                layers.Dense(channels // ratio, activation='relu'),
                layers.Dense(channels)
            ])

            avg_out = shared_mlp(add_out)
            max_out = shared_mlp(add_out)
            scale = tf.nn.sigmoid(avg_out + max_out)
            return x * scale

        # ----- Spatial Attention -----
        def spatial_attention(x):
            avg_pool = tf.reduce_mean(x, axis=-1, keepdims=True)
            max_pool = tf.reduce_max(x, axis=-1, keepdims=True)
            concat = tf.concat([avg_pool, max_pool], axis=-1)
            scale = layers.Conv1D(1, kernel_size=7, padding='same', activation='sigmoid')(concat)
            return x * scale
            # Channel attention

        ch_att = channel_attention(out_lrelu)
        # Spatial attention
        sp_ch_attention = spatial_attention(ch_att)

        sigma = tf.math.reduce_variance(sp_ch_attention)
        alpha = 0.6
        Thr = alpha * sigma

        def fuzzy_threshold(x, thr=0.5):
            # Case 1: x > thr → x - thr
            pos_case = tf.where(x > thr, x - thr, tf.zeros_like(x))
            # Case 2: x < -thr → x + thr
            neg_case = tf.where(x < -thr, x + thr, tf.zeros_like(x))
            # Combine both cases
            return pos_case + neg_case

        # Wrap in a Lambda layer for Keras usage
        Thr = 0.6  # example threshold
        fsh_layer = layers.Lambda(lambda t: fuzzy_threshold(t, Thr))

        fsh = fsh_layer(sp_ch_attention)

        return fsh



    # Spatial Pyramid Pooling placeholder for 1D
    def spatial_pyramid_pool(x):
        pool1 = layers.GlobalAveragePooling1D()(x)
        pool2 = layers.GlobalMaxPooling1D()(x)
        concat = layers.Concatenate()([pool1, pool2])
        return concat

    # ----- Model Definition -----
    def build_cnn_lstm_1d(input_shape, num_classes=1):
        inputs = layers.Input(shape=input_shape)

        # Conv Block 1
        x = layers.Conv1D(32, 3, padding='same')(inputs)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU()(x)
        x = fuzzy_cbam_ss(x)

        # Conv Block 2
        x = layers.Conv1D(64, 3, padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.Activation('tanh')(x)
        x = fuzzy_cbam_ss(x)

        # Conv Block 3
        x = layers.Conv1D(128, 3, padding='same')(x)
        x = layers.BatchNormalization()(x)
        x = layers.LeakyReLU()(x)

        # Spatial Pyramid Pool
        spp = spatial_pyramid_pool(x)
        spp = tf.expand_dims(spp, axis=1)  # make it sequence-like for LSTM
        spp = fuzzy_cbam_ss(spp)

        # LSTM
        lstm_out = layers.LSTM(64, return_sequences=False)(spp)
        lstm_out = layers.Dropout(0.5)(lstm_out)

        # Fully Connected
        fc = layers.Dense(64, activation='relu')(lstm_out)
        fc = layers.BatchNormalization()(fc)
        fc = layers.Dropout(0.5)(fc)
        fc = layers.Dense(64, activation='relu')(fc)

        outputs = layers.Dense(ln, activation='sigmoid')(fc)

        model = models.Model(inputs, outputs)
        return model

    # ----- Build & Compile -----
    input_shape = (X_train.shape[1], 1)  # Example: 500-sample ECG signal, single channel
    model = build_cnn_lstm_1d(input_shape)

    model.compile(optimizer=optimizers.Adam(1e-3),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])

    model.summary()
    y_train_cat=tf.keras.utils.to_categorical(Y_train)
    # ----- Fit -----
    model.fit(X_train, y_train_cat, epochs=ep, batch_size=128, validation_split=0.2,verbose=0)
    # ----- Prediction -----
    preds = np.argmax(model.predict(X_test),axis=1)
    return preds

def prop_lb(X_train, X_test, Y_train, Y_test, db):
    # ######## <<<<< Classification >>>>>>>>> ########
    print('proposed CNN_LSTM \n')
    predict=imp_cnn_lstm(X_train, X_test, Y_train, Y_test, db)
    return predict


def comp(X_train, X_test, Y_train, Y_test, db):
    pred = [bp1_, bp2_, lstm_, efficient_net, conv_shufflenet_, lenet_, dense_net_]
    pos = len(pred)
    lp = np.load('pre_evaluated/tp.npy')
    pred_out = []
    for i in range(0, pos):
        print('lp=' + str(lp) + '_method=' + str(i))
        out, y_pred, cm, ttn = pred[i](X_train, Y_train, X_test, Y_test, db)
        pred_out.append(y_pred)
    return pred_out

def method(X_train, X_test, Y_train, Y_test):
    vv = []
    vv.extend(comp(X_train, X_test, Y_train, Y_test, db))
    vv.append(prop_lb(X_train, Y_train, X_test, Y_test, db))
    return vv


def multi_run_validation(feat,label,db):
    learn_percent, learning_percentage = [ 0.8], ['80']
    lp = 0.8
    for loop in range(10):
        # for lp, lpstr in zip(learn_percent, learning_percentage):
        feat = feat / np.max(feat)
        X_train, X_test, Y_train, Y_test = train_test_split(feat, label, test_size=lp, stratify=label ,random_state=42)  # reproducibility


        # np.save(f'pre_evaluated/Actual-sevv-' + str(lps

        np.save('pre_evaluated/Y_test', Y_test)
        np.save('pre_evaluated/tp', lp)
        pred_va = np.array(method(X_train, X_test, Y_train, Y_test))
        # np.save('pre_evaluated/Predicted-sevv-' + str(lpstr) + str(db), pred_va)
        out = np.array([metrices_(pre, Y_test) for idx, pre in enumerate(pred_va)])
        result_ = np.array([out[i][0] for i in range(len(out))])
        TPTN = np.array([out[i][1][0] for i in range(len(out))])
        CM = np.array([out[i][1][1] for i in range(len(out))])
        #  bp1_,bp2 , bigru_, conv_parallel_Cnn, dense_net,bilstm_, efficientnet
        clmn = ['Base1', 'Base2', 'LSTM', 'Efficientnet', 'Shufflenet', 'Lenet', 'Densenet', 'PROPOSED']

        indx = ['accuracy', 'sensitivity', 'specificity', 'precision', 'f_measure', 'mcc', 'npv', 'fpr', 'fnr']
        globals()['df' + f'{loop}'] = pd.DataFrame(result_.transpose(), columns=clmn, index=indx)
        indx1 = ['TP', 'TN', 'FP', 'FN']

    key = np.arange(10).tolist()
    run_multi = [df0, df1, df2, df3, df4, df5, df6, df7, df8, df9]
    try:
        frames = run_multi
    except:
        frames = run_multi
    df = pd.concat(frames, keys=key, axis=0)
    if rn: df.to_csv(f'pre_evaluated/performance_Statistical{db}.csv')




def learning_rate_analysis(db):

    def prop_lb_lr(lr):
        y_pred =prop_lb(X_train, Y_train, X_test, Y_test, db)
        out = multi_confu_matrix(Y_test, y_pred)
        return out[0]


    feat, lab = load_data(db)

    learn_rate = [0.1, 0.01, 0.001]

    X_train, X_test, Y_train, Y_test = train_test_split(feat, lab, test_size=0.1, random_state=0)
    np.save(f'pre_evaluated/Y_test', Y_test)
    np.save('pre_evaluated/tp', 0.8)
    result = [prop_lb_lr(lr) for _, lr in enumerate(learn_rate)]
    accuracy = np.array ([result[i] for i in range(len(result))]  )  # accuracy = np.array([result[i][0] for i in range(len(result))])

    val = pd.read_csv('pre_evaluated/saved/Performance-' + str(db) + '.csv', index_col=[0, 1])
    new_ = val.loc[([80], ), :]
    prop_acc = new_.values[: ,-1]
    acc = np.concatenate((accuracy, prop_acc.reshape(1 ,-1)))
    # acc = np.concatenate((accuracy, prop_acc))
    # ct = np.array([result[i][1] for i in range(len(result))], axis=1) # tme = np.concatenate((ct, ct1))
    lrn_rate = ['0.1', '0.01', '0.001', '0.0001']
    indx =  ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']
    globals()['df' + 'lr'] = pd.DataFrame(acc.T, columns=lrn_rate, index=indx)
    a=1
    # dflr
    # np.save('saved data/lt_varied'+str(db),acc)
    # globals()['df1' + 'ct'] = pd.DataFrame(tme.reshape(1, -1), columns=lrn_rate, index=indx1)



   # clmn = ['RF+KNN+XGBOOST', 'DNN', 'CNN', 'Lenet', 'Bilstm', 'linknet', 'Rnn', 'LIRNN']
    name1 = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']

    lrn_rate = ['0.1', '0.01', '0.001', '0.0001']
    lr_var = np.load('saved data/lt_varied'+str(db)+'.npy')
    df = pd.DataFrame(lr_var, columns=name1,index=lrn_rate)
    df.index.name = 'Learning Rate'

    print(df.to_markdown())
    # df.to_csv('Results/'+ 'parametric_analysis_based_learning_rate.csv')



if rn==1:
    learning_rate_analysis(1)

    multi_run_validation(feat,label,1)