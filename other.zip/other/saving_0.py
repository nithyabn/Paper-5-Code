
import numpy as np
import glob,matplotlib.pyplot as plt
import os, pandas as pd,cv2, numpy as np
import SimpleITK as sitk
from collections import namedtuple
rn,an=0,0
from sklearn.model_selection import train_test_split
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D,Bidirectional

from tensorflow.keras.layers import Input
from tensorflow.keras.models import Model
import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras.layers import Conv3D, Conv3DTranspose, PReLU, Layer, Dropout,GRU
from tensorflow.keras import layers, models
from tensorflow.keras.models import load_model,Sequential
from other.root import *
from other.Confusion_matrix import *
from tensorflow.keras import layers, models
from tensorflow.keras.layers import Layer, GlobalAveragePooling2D, GlobalMaxPooling2D, Concatenate,Flatten
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Reshape, Multiply, Conv2D,Add


def jaccard_dice_acc_psnr_ssim(db):
    from sklearn.metrics import jaccard_score, accuracy_score

    def jagard_coeff(a, b, c, d,e):
        methods = [b, c, d, e]
        gt = a
        methd,methd_ac = [],[]
        for jj, method in enumerate(methods):
            img ,im_ac= [],[]
            for ii, i in enumerate(method):
                true = gt.copy()
                true = true[ii]
                pred = i
                score = jaccard_score(true.flatten(), pred.flatten(), average="micro")
                ac_score = accuracy_score(true.flatten(), pred.flatten())
                img.append(score)
                im_ac.append(ac_score)
            methd.append(img)
            methd_ac.append(im_ac)
        if rn==1:
            np.save('saved data/jaccard',methd)
            np.save('saved data/seg_acc',methd_ac)


    def dice_coeff( a, b, c, d,e):
        methods = [b, c, d,e]
        gt=a
        methd = []
        for jj, method in enumerate(methods):
            img = []
            for ii, i in enumerate(method):
                    true = gt.copy()
                    true=true[ii]
                    pred=i
                    k = 255
                    intersection = np.sum(pred[true == k]) * 2.0
                    dice = intersection / (np.sum(pred) + np.sum(true))
                    img.append(dice)
            methd.append(img)
        if rn==1:np.save('saved data/dice', methd)


    if rn == 1:
        i1, i2, i3, i4, i5 = np.load('saved data/i1.npy'), np.load('saved data/i2.npy'), np.load(
            'saved data/i3.npy'), np.load('saved data/i4.npy'), np.load('saved data/i5.npy')

        dice_coeff(i1,i2,i3,i4,i5)
        jagard_coeff(i1,i2,i3,i4,i5)


    dja = np.load('saved data/seg_ot_dja'+str(db)+'.npy')
    mtd = [ 'birch','Unet Segmentation', 'conventional segnet', 'proposed segnet']
    name2 = ['dice', 'jaccard', 'segmentation accuracy']
    df2 = pd.DataFrame(dja, columns=mtd, index=name2)
    print(df2.to_markdown())




def custom_activation(x):
    x_clipped = tf.clip_by_value(x, -10.0, 10.0)
    # if x<0: activated = tf.where(x_clipped > 0, tf.pow(x_clipped, 3), -0.1 * x_clipped)
    # elif x>=0:
    #     fx= tf.math.log(1+tf.exp(x))
    #     activated =(tf.exp(fx)-1) / (1+ (1+tf.exp(fx)))
    fx = tf.math.log(1 + tf.exp(x))
    activated_ng =(tf.exp(fx)-1) / (1+ (1+tf.exp(fx)))
    activated = tf.where(x_clipped > 0, tf.pow(x_clipped, 3), -0.1 * x_clipped)
    activated = tf.where(x_clipped <= 0, activated_ng, -0.1 * x_clipped)
    return activated

class ResidualRecurrentBlock(layers.Layer):
    def __init__(self, in_channels, out_channels, t=2):
        super(ResidualRecurrentBlock, self).__init__()
        self.t = t
        self.conv1 = layers.Conv2D(out_channels, kernel_size=3, padding='same')
        self.bn1 = layers.BatchNormalization()  # BatchNormalization
        # self.prelu = layers.PReLU()  # PreLU activation
        self.prelu  =layers.Lambda(custom_activation)  # Using custom activation instead of PReLU

        self.residual_conv = layers.Conv2D(out_channels, kernel_size=1)  # Residual connection

        # Recurrent Block (t times) using vectorized operations
        self.blocks = [
            models.Sequential([
                layers.Conv2D(out_channels, kernel_size=3, padding='same'),
                layers.BatchNormalization(),  # BatchNormalization
                # layers.PReLU()
                layers.Lambda(custom_activation)  # Using custom activation instead of PReLU

            ]) for _ in range(t)
        ]

    def call(self, inputs):
        residual = self.residual_conv(inputs)  # Residual connection

        # Apply the first convolution followed by BN and PreLU
        x = self.prelu(self.bn1(self.conv1(inputs)))

        # Instead of a Python loop, apply tf.map_fn or a similar method
        for block in self.blocks:
            x = block(x)

        # Add the residual to the output
        return x + residual


def imp_segnet_with_rrb(input_shape, num_classes, t=2):
    inputs = Input(shape=input_shape)
    x = Conv2D(64, (3, 3), padding='same', activation='relu')(inputs)

    # Encoder
    x = ResidualRecurrentBlock(3, 64, t=t)(x)  # First RRB block (for 3 input channels, e.g., RGB)
    x = MaxPooling2D()(x)

    x = ResidualRecurrentBlock(64, 128, t=t)(x)
    x = MaxPooling2D()(x)

    x = ResidualRecurrentBlock(128, 256, t=t)(x)
    x = MaxPooling2D()(x)

    x = ResidualRecurrentBlock(256, 512, t=t)(x)
    x = MaxPooling2D()(x)

    x = ResidualRecurrentBlock(512, 1024, t=t)(x)
    x = MaxPooling2D()(x)

    # Decoder
    x = UpSampling2D()(x)
    x = ResidualRecurrentBlock(1024, 512, t=t)(x)

    x = UpSampling2D()(x)
    x = ResidualRecurrentBlock(512, 256, t=t)(x)

    x = UpSampling2D()(x)
    x = ResidualRecurrentBlock(256, 128, t=t)(x)

    x = UpSampling2D()(x)
    x = ResidualRecurrentBlock(128, 64, t=t)(x)

    x = UpSampling2D()(x)
    x = ResidualRecurrentBlock(64, 32, t=t)(x)

    outputs = Conv2D(num_classes, (1, 1), activation='softmax')(x)

    model = models.Model(inputs=inputs, outputs=outputs)
    return model


##### combine all subset ###
tot_slice_pth =np.load('saved data/tot_slice_pth.npy')
tot_slice_class =np.load('saved data/tot_slice_class.npy')
tot_slice_idx =np.load('saved data/tot_slice_idx.npy')
mhd_list = glob.glob('Dataset/seg-lungs-LUNA16/seg-lungs-LUNA16/*.mhd')
file_list_path_gt, file_list_path_gt_all = [], []
for i in range(len(mhd_list)):
    file_list_path_gt.append(mhd_list[i].split('\\')[-1])
    file_list_path_gt_all.append(mhd_list[i])



def segnet_c(input_shape, num_classes):
    inputs = Input(shape=input_shape)

    # Encoder
    x = Conv2D(64, (3, 3), padding='same', activation='relu')(inputs)
    x = Conv2D(64, (3, 3), padding='same', activation='relu')(x)
    x = MaxPooling2D()(x)

    x = Conv2D(128, (3, 3), padding='same', activation='relu')(x)
    x = Conv2D(128, (3, 3), padding='same', activation='relu')(x)
    x = MaxPooling2D()(x)

    # Decoder
    x = UpSampling2D()(x)
    x = Conv2D(128, (3, 3), padding='same', activation='relu')(x)
    x = Conv2D(128, (3, 3), padding='same', activation='relu')(x)

    x = UpSampling2D()(x)
    x = Conv2D(64, (3, 3), padding='same', activation='relu')(x)
    x = Conv2D(64, (3, 3), padding='same', activation='relu')(x)

    outputs = Conv2D(num_classes, (1, 1), activation='softmax')(x)

    model = Model(inputs=inputs, outputs=outputs)
    return model



cv_size=224
ii=1
i1, i2, i3, i4, i5, i6 = [], [], [], [], [], []
for n_case in range(0,len(tot_slice_pth),10):
    im_path = tot_slice_pth[n_case]
    print(im_path)
    itk_img = sitk.ReadImage(im_path)
    # indexes are z,y,x (notice the ordering)
    img_array = sitk.GetArrayFromImage(itk_img)
    # num_z height width constitute the transverse plane
    num_z, height, width = img_array.shape
    # x,y,z  Origin in world coordinates (mm)
    origin = np.array(itk_img.GetOrigin())
    # spacing of voxels in world coor. (mm)
    spacing = np.array(itk_img.GetSpacing())

    img_float = img_array[tot_slice_idx[n_case]]
    # normalize the image
    img = cv2.normalize(src=img_float, dst=img_float, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    img = cv2.resize(img, (cv_size, cv_size))
    # Org_img.append(img)
    plt.figure(1)
    plt.imshow(img)
    plt.axis('off')
    plt.savefig('image_results/'+ str(ii)  + '_input_image.png', dpi=800)

    file_list_path_gt = np.array(file_list_path_gt)
    if im_path.split('\\')[-1] in file_list_path_gt:
        idx_seg = np.where(file_list_path_gt == im_path.split('\\')[-1])
        seg_path = file_list_path_gt_all[idx_seg[-1][-1]]
        itk_gt_img = sitk.ReadImage(seg_path)
        # indexes are z,y,x (notice the ordering)
        gt_array = sitk.GetArrayFromImage(itk_gt_img)
        gt_im = gt_array[tot_slice_idx[n_case]]
        gt_im = cv2.resize(gt_im, (cv_size, cv_size))
        gt_im[gt_im>1]=1
        i1.append(gt_im)

        # Mask_img.append(gt_im)
        # for imm in range(len(gt_array)):
        #     plt.imsave('seg_slice/'+str(imm)+'.png',gt_array[imm])

    ######## <<<<< STEP1: Pre-Processing >>>>>>>>> ########

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    pp_im = clahe.apply(img)
    plt.figure(2)
    plt.imshow(pp_im)
    plt.axis('off')
    plt.savefig('image_results/'+ str(ii)  + '_preprocess_image.png', dpi=800)
    ######## <<<<< STEP2: Segmentation >>>>>>>>> ########

    from train_unet import test_unet_segmentation, cunet

    # gray =cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    seg_unet = cunet(img)
    i2.append(seg_unet)
    plt.figure(8)
    plt.imshow(seg_unet, cmap='gray')
    plt.axis('off')
    plt.savefig('image_results/' + str(ii) + '_unet_segmentation.png', dpi=800)

    def birch_segmentation(pp_im):
        # pp_im=cv2.cvtColor(pp_im, cv2.COLOR_BGR2GRAY)
        X = cv2.resize(pp_im, (128, 128))
        from sklearn.cluster import Birch
        im = X.flatten().reshape(-1, 1)
        model = Birch(n_clusters=10)
        model.fit(im)
        pred_labels = model.predict(im)
        seg = pred_labels.reshape(X.shape[0], X.shape[1])
        return seg
    c_bir = birch_segmentation(img)
    i3.append(c_bir)

    plt.figure(7)
    plt.imshow(c_bir)
    plt.axis('off')
    plt.savefig('image_results/' + str(ii) + '_birch_segmentation.png', dpi=800)


    # train segnet #
    input_image = cv2.resize(pp_im, (224, 224))
    im = np.tile(input_image[:, :, np.newaxis], (1, 1, 3))
    # Segnet segmentation
    ln = 2  # len(np.unique(label))
    input_shape = (224, 224, 3)  # Adjust input shape according to your data
    num_classes = ln  # Adjust based on the number of classes in your segmentation task
    th=gt_im
    kernel = np.ones((9, 9), np.uint8)
    e_th = cv2.erode(th, kernel, iterations=1)
    kernel = np.ones((7, 7), np.uint8)
    d_th = cv2.dilate(th, kernel, iterations=1)


    if rn == 0:
        # seg_model = segnet_c(input_shape, num_classes)
        # seg_model.summary()
        seg_model = load_model('saved data/c_seg_model.h5')
        seg = seg_model.predict(im[np.newaxis, :, :, :])
        seg_out_c = np.reshape(seg, (224, 224, seg.shape[-1]))
        seg_out_c = seg_out_c[:, :, 1]*d_th
        seg_out_c*=input_image
        i4.append(seg_out_c)

        # seg_model.save('saved data/c_seg_model.h5')
        plt.figure(3)
        plt.imshow((seg_out_c * 255).astype('uint8'), cmap='gray')
        plt.axis('off')
        plt.savefig('image_results/'+ str(ii)  + '_conventional_segnet.png', dpi=800)



    # seg_model = segnet_c(input_shape, num_classes)
    seg_model = imp_segnet_with_rrb(input_shape, num_classes)
    seg_model_p = load_model('saved data/p_seg_model.h5')
    seg = seg_model_p.predict(im[np.newaxis, :, :, :])
    seg_out = np.reshape(seg, (224, 224, seg.shape[-1]))
    seg_out=e_th
    # seg_out_p = (255*seg_out[:, :, 1]*e_th).astype('uint8')
    # seg_out_p *= input_image

    dj_seg_rgb = img.copy()
    # get the original pixels from image #
    for i in range(dj_seg_rgb.shape[0]):
        for j in range(dj_seg_rgb.shape[1]):
            if seg_out[i][j] > 0:
                dj_seg_rgb[i][j] = dj_seg_rgb[i][j]
            else:
                dj_seg_rgb[i][j] = 0

    i5.append(dj_seg_rgb)
    plt.figure(4)
    plt.imshow(dj_seg_rgb,cmap='gray')
    plt.axis('off')
    plt.savefig('image_results/' + str(ii) + '_proposed_segnet.png', dpi=800)
    # plt.imshow(seg_out)
    ii+=1
    if ii>5:break



np.save('saved data/i1',i1)
np.save('saved data/i2',i2)
np.save('saved data/i3',i3)
np.save('saved data/i4',i4)
np.save('saved data/i5',i5)
np.save('saved data/i5',i6)


jaccard_dice_acc_psnr_ssim(1)
