import pandas as pd, numpy as np
# from colorama import Fore, init
import matplotlib.pyplot as plt
from other.Confusion_matrix import *
import statistics,cv2
from matplotlib import style
# style.use('seaborn-whitegrid')
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc
rn=0




def roc_plot_multi(y_test,y_score1,label,y,clr):
    plt.figure(figsize=(9,5))
    cll = np.unique(y_test)

    for ii in range(len(y_score1)):
        y_score = y_score1[ii][:len(y_test)]
        # Binarize
        y_test = label_binarize(y_test, classes=cll)
        y_score = label_binarize(y_score, classes=cll)
        n_classes = y_test.shape[1]

        # Compute ROC curve and ROC area for each class
        fpr = dict()
        tpr = dict()
        roc_auc = dict()
        for i in range(n_classes):
            fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
            roc_auc[i] = auc(fpr[i], tpr[i])

        # Compute micro-average ROC curve and ROC area
        fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score.ravel())
        roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
        plt.plot(fpr[2], tpr[2], label=label[ii], color=clr[ii], marker='*', markersize=15,markerfacecolor='k')

        # plt.plot(fpr[2], tpr[2], label=label[ii] + '(area = %0.2f)' % roc_auc[2],color=clr[ii])

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', weight='bold', size=16)
    plt.ylabel('True Positive Rate', weight='bold', size=16)
    plt.title('Receiver operating characteristic', weight='bold', size=16)
    plt.subplots_adjust(bottom=0.25)
    plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.45), ncol=4, fontsize=14)
    plt.savefig('Results/' +str(y)+'_roc.png',dpi=800)
    plt.show(block=False)


def roc_plot(y_test,y_score1,label,y,clr):
    plt.figure(figsize=(9,5))
    for ii in range(len(y_score1)):
        y_score=y_score1[ii][:len(y_test)]

        # Compute ROC curve and ROC area for each class
        fpr = dict()
        tpr = dict()
        roc_auc = dict()
        fpr[0], tpr[0], _ = roc_curve(y_test, y_score)
        roc_auc[0] = auc(fpr[0], tpr[0])
        # Compute micro-average ROC curve and ROC area
        fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score)
        roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
        # plt.plot(fpr[0], tpr[0], label=label[ii] + '(area = %0.2f)' % roc_auc[0],color=clr[ii])
        plt.plot(fpr[0], tpr[0], label=label[ii] ,color=clr[ii])

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', weight='bold', size=16)
    plt.ylabel('True Positive Rate', weight='bold', size=16)
    plt.title('Receiver operating characteristic', weight='bold', size=16)
    plt.legend(loc="lower right")
    plt.savefig('Results/' +str(y)+'_roc.png',dpi=800)
    plt.show(block=False)



def stat_analysis(xx):
    mn = np.mean(xx, axis=0).reshape(-1, 1)
    mdn = np.median(xx, axis=0).reshape(-1, 1)
    std_dev = np.std(xx, axis=0).reshape(-1, 1)
    min = np.min(xx, axis=0).reshape(-1, 1)
    mx = np.max(xx, axis=0).reshape(-1, 1)
    return np.concatenate((mn, mdn, std_dev, min, mx), axis=1)

def roc_plot(y_test, y_score1, label, db, clr):
    plt.figure()
    for ii in range(len(y_score1)):
        y_score = y_score1[ii][:len(y_test)]

        # Compute ROC curve and ROC area for each class
        fpr = dict()
        tpr = dict()
        roc_auc = dict()
        fpr[0], tpr[0], _ = roc_curve(y_test, y_score)
        roc_auc[0] = auc(fpr[0], tpr[0])
        # Compute micro-average ROC curve and ROC area
        fpr["micro"], tpr["micro"], _ = roc_curve(y_test.ravel(), y_score)
        roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])
        plt.plot(fpr[0], tpr[0], label=label[ii],marker='D',color=clr[ii])

        # plt.plot(fpr[0], tpr[0], label=label[ii] + '(area = %0.2f)' % roc_auc[0])

    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', weight='bold', size=16)
    plt.ylabel('True Positive Rate', weight='bold', size=16)
    plt.title('Receiver operating characteristic', weight='bold', size=16)
    plt.legend(loc="lower right")
    plt.savefig('Results/' + str(db) + '_roc.png',dpi=800)
    plt.show(block=False)



def plotresult():
        db=1
        from colorama import Fore, init
        # clmn = ['Base1', 'Base2', 'LSTM', 'Efficientnet', 'Shufflenet', 'Lenet', 'Densenet', 'PROPOSED']
        clmn = ['CNN-LSTM', 'XGBoost', 'LSTM', 'Efficientnet', 'Shufflenet', 'Lenet', 'Densenet', 'En-CNN-LSTM']
        lp1 = '80'
        custom_colors = ['#20e856','#ec40f5', '#f2ad22', '#5576ed',  '#bc88f7','#61ffff','#faee4d', 'r']
        # custom_colors = ['#9c9a95','#26fc78', '#d927be', '#8f8c36',  '#793a99','#6a8d8f','#f5f542', '#f74a5e']

        plt.rc('font', weight='bold',size=16)

        #
        # sspr = np.load('saved data/ssim_psnr' + str(db) + '.npy')
        # # import pandas as pd
        # df = pd.DataFrame(sspr, columns=['PSNR', 'SSIM'],index=[ 'clahe','gaussian','median','conv medAV filter', 'improved medAv filter'])
        # print('\n')
        # print(df.to_markdown())
        # df.to_csv('Results/'+ 'ssim_psnr_table.csv')

        name1 = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']

        lrn_rate = ['0.1', '0.01', '0.001', '0.0001']
        lr_var = np.load('saved data/lt_varied' + str(db) + '.npy')
        df = pd.DataFrame(lr_var, columns=name1, index=lrn_rate)
        df.index.name = 'Learning Rate'
        print(df.to_markdown())
        df.to_csv('Results/' + 'parametric_analysis_based_learning_rate.csv')

        df1 = df.iloc[:, :7]
        # ax = df1.plot(figsize=(10, 6), kind='line', use_index=True, rot=0, color=custom_colors,edgecolor='black')
        import matplotlib.cm as cm
        markercolors = cm.tab10(np.linspace(0, 1, df1.shape[1]))
        ax = df1.plot(marker="o", figsize=(10, 6),markersize=14,color=markercolors)

        for line in ax.get_lines():
            line.set_markeredgecolor("black")  # outline color
            line.set_markeredgewidth(1.5)  # outline thickness
            line.set_markerfacecolor(line.get_color())  # keep face color same as line

        # plt.ylim(0.6, 1)
        plt.xlabel('Learning Rate', fontweight='bold', size=16)
        plt.ylabel('Performance', fontweight='bold', size=16)
        plt.subplots_adjust(bottom=0.25)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.38), ncol=4, fontsize=14)
        plt.savefig('Results/'+ 'learning_rate_positive_measure' + '.png', dpi=800)





        act = np.load('pre_evaluated/saved/Actual-'  + lp1 + str(db) + '.npy')
        pred = np.load('pre_evaluated/saved/Predicted-'  + lp1 + str(db) + '.npy')
        roc_plot(act, pred, clmn, db,custom_colors)

        # dja = np.load('saved data/seg_ot_dja' + str(db) + '.npy')
        # mtd = ['birch', 'Unet Segmentation', 'conventional segnet', 'proposed segnet']
        # name2 = ['dice', 'jaccard', 'segmentation accuracy']
        # df2 = pd.DataFrame(dja, columns=mtd, index=name2)
        # print(df2.to_markdown())
        # df2.to_csv('Results/' + 'dice_jaccard_segmentation_accuracy.csv')

        key = np.arange(10).tolist()
        plot_result = pd.read_csv(f'pre_evaluated/saved/performance_Statistical{db}.csv', index_col=[0, 1])
        stat = plot_result.loc[(key, ['accuracy']), :].values
        stat = stat_analysis(stat).transpose()
        df_ = pd.DataFrame(stat, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],clmn)
        print(df_.to_markdown())
        df_.to_csv(f'Results/statistics analysis_based_on_accuracy{db}.csv')

        def Conf_interval():
            from scipy.stats import t
            def Confidence_interval(sample_data, confidence_level=0.95):
                sample_data = np.array(sample_data).flatten()
                sample_mean = np.mean(sample_data)
                sample_std = np.std(sample_data, ddof=1)
                n = len(sample_data)
                standard_error = sample_std / np.sqrt(n)
                df = n - 1

                confidence_interval = t.interval(confidence_level, df, loc=sample_mean, scale=standard_error)
                return confidence_interval

            ### Dataset1
            # Load classifier accuracy results
            # df1 = pd.read_csv('pre_evaluated/saved/Optimization.csv', index_col=[0, 1])
            # df1 = pd.read_csv('pre_evaluated/saved/Performance-' + str(db) + '.csv', index_col=[0, 1])

            # Initialize a dictionary to store confidence intervals
            conf_dict = {}
            conf_interval_res = []
            # Extract unique methods
            methods = plot_result.columns

            # Iterate through each method and calculate its confidence interval
            for method in methods:
                data = plot_result.loc[(slice(None), 'accuracy'), method].values#df1.loc[(slice(None), 'accuracy'), method].values  # accuracy
                conf_interval = Confidence_interval(data)
                conf_interval_res.append(conf_interval)
                conf_dict[method] = [f"[{conf_interval[0]:.4f}, {conf_interval[1]:.4f}]"]
            # # Create DataFrame
            # conf_interval_res = np.load('saved data/conf_interval_res.npy')
            # dff = pd.DataFrame(conf_interval_res, index=name1)
            # dff
            # # dff.to_csv('Results_JC_19_9_25/confidence_interval.csv')

            df_conf = pd.DataFrame.from_dict(conf_dict, orient='index', columns=['Confidence Interval'])
            print(df_conf)
            # Save to CSV
            df_conf.to_csv('Results/confidence_interval_based_accuracy.csv')

        if rn==0:Conf_interval()



        def accuracy_errortable(db):


            val = np.arange(10).tolist()
            stat = plot_result.loc[(val, ['accuracy']), :].values
            stat = stat_analysis(stat).transpose()

            # new_ = state.loc[([90], ['accuracy']), :]
            mean_accuracies = stat[0]
            std_devs = stat[2]

            # Create DataFrame
            df = pd.DataFrame({
                "Model": clmn,
                # "Mean Accuracy": mean_accuracies,
                # "Std Dev": std_devs,
                "Mean ± Std": [f"{m:.4f} ± {s:.4f}" for m, s in zip(mean_accuracies, std_devs)]
            })
            df1=df

            stat = plot_result.loc[(val, ['precision']), :].values
            stat = stat_analysis(stat).transpose()
            # new_ = state.loc[([90], ['accuracy']), :]
            mean_accuracies = stat[0]
            std_devs = stat[2]
            # Create DataFrame
            df = pd.DataFrame({
                "Model": clmn,
                "Mean ± Std": [f"{m:.4f} ± {s:.4f}" for m, s in zip(mean_accuracies, std_devs)]
            })
            df2=df

            stat = plot_result.loc[(val, ['sensitivity']), :].values
            stat = stat_analysis(stat).transpose()
            # new_ = state.loc[([90], ['accuracy']), :]
            mean_accuracies = stat[0]
            std_devs = stat[2]
            # Create DataFrame
            df = pd.DataFrame({
                "Model": clmn,
                "Mean ± Std": [f"{m:.4f} ± {s:.4f}" for m, s in zip(mean_accuracies, std_devs)]
            })
            df3 = df

            stat = plot_result.loc[(val, ['f_measure']), :].values
            stat = stat_analysis(stat).transpose()
            # new_ = state.loc[([90], ['accuracy']), :]
            mean_accuracies = stat[0]
            std_devs = stat[2]
            # Create DataFrame
            df = pd.DataFrame({
                "Model": clmn,
                "Mean ± Std": [f"{m:.4f} ± {s:.4f}" for m, s in zip(mean_accuracies, std_devs)]
            })
            df4 = df

            # vv_mean_std=[df1,df2,df3,df4]
            vv_mean_std=np.array([df1.values[:,-1],df2.values[:,-1],df3.values[:,-1],df4.values[:,-1]])

            df = pd.DataFrame(vv_mean_std.T,index=clmn,columns=['accuracy','precision','recall','f-measure'])

            print(df.to_markdown())

            # Save to CSV for manuscript use
            df.to_csv(f'Results/Mean ± Std over 10 times run{db}.csv',encoding="utf-8-sig")

        accuracy_errortable(db)


        kf = np.load('saved data/perf_A_KF' + str(db) + '.npy')
        df = pd.DataFrame(kf, columns=clmn, index=['fold-1', 'fold-2', 'fold-3', 'fold-4', 'fold-5'])
        print(df.to_markdown())
        df.to_csv(f'Results/' + str(db) +'k-fold analysis' + '.csv')


        val = pd.read_csv('pre_evaluated/saved/Performance-' + str(db) + '.csv', index_col=[0, 1])

        # ablation atudy #
        name1 = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']
        ablation = pd.read_csv(f'pre_evaluated/saved/ablation_study' + str(db) + '.csv', header=0)
        print('\nfeature comparison')
        cla_tab = ablation.iloc[:, 1:].values
        Tab = np.empty([len(name1), cla_tab.shape[1] + 1])
        Tab[:, :Tab.shape[1] - 1] = cla_tab
        Tab[:, Tab.shape[1] - 1] = val.loc[([int(lp1)]), :]['PROPOSED'].values
        df = pd.DataFrame(Tab, columns=['without adaptive feature fusion', 'with gene ontology feature', 'network based feature',
                'with sequence based feature', 'conventional cnn_lstm',
                                   'proposed'],
                          index=name1)

        cols = list(df.columns)
        cols[-1] = clmn[-1]
        df.columns = cols
        print(df.to_markdown())
        df.to_csv(f'Results/' +'ablation_study' + '.csv')

        df_ablation = df[0:7]
        plt.figure(figsize=(10, 6))
        hatches = ['', '\\x', '.|', '*-', '..', 'o+', '\\-']  # cycle of hatch styles
        ab_label = df_ablation.columns
        X = df_ablation.values
        br1 = np.arange(len(X))
        for i in range(X.shape[1]):
            plt.bar(br1, X[:, i], color=custom_colors[i], width=0.12,
                    edgecolor='k', linewidth=1.2, label=ab_label[i], hatch=hatches[i], zorder=3)
            br1 = [x + 0.125 for x in br1]
        plt.xticks([r + 0.3 for r in range(len(X))],
                   df_ablation.index, size=14, rotation=15)
        # Set the hatch pattern for each bar
        # ax = df_ablation.plot(figsize=(12, 6), kind='bar', width=0.6, use_index=True, rot=0, color=custom_colors,edgecolor='black',lw=2)
        plt.ylabel('Performance', fontweight='bold', size=16)
        plt.subplots_adjust(bottom=0.4)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.6), ncol=2, fontsize=12)
        plt.savefig('Results/' + 'ablation_analysis' + '.png', dpi=800)




        # training % varied results #
        indx = ['accuracy', 'sensitivity', 'specificity', 'precision', 'f_measure', 'mcc', 'npv', 'fpr', 'fnr']
        plot_result = pd.read_csv('pre_evaluated/saved/Performance-' + str(db) + '.csv', index_col=[0, 1])
        plot_result.columns = clmn


        def hatching_plot(X, clr=None, index=None, xlabel=None, ylable=None, case=None):
            import matplotlib.pyplot as plt
            from matplotlib.patches import Ellipse, Polygon
            br1 = np.arange(4)
            # plt.style.use('grayscale')
            plt.figure(figsize=[9, 6])
            # plt.figure()
            # hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', 'OO', '||', '**']
            # hatches = ['/o', '\\|', '|*', '-\\', '+o', 'x*', 'o-', 'O|', 'O.', '*-']
            hatches = ['/o', '\\|', '|.', '-\\', '--', 'xo', 'o-', 'O|', 'O.', '*-']
            for i in range(X.shape[1]):
                plt.bar(br1, X[:, i], color=clr[i], width=0.1,
                        edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i], zorder=3)

                br1 = [x + 0.105 for x in br1]
            plt.subplots_adjust(bottom=0.3)
            # plt.grid(color='g', linestyle=':', linewidth=1.2)
            plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.5), fontsize=14, ncol=3,
                       frameon=True, framealpha=1, edgecolor='black', fancybox=True)
            plt.xlabel(xlabel, weight='bold', size=18)
            plt.ylabel(ylable, weight='bold', size=18)
            plt.xticks([r + 0.3 for r in range(4)],
                       ['60', '70', '80', '90'], size=14)
            plt.yticks(size=14)
            plt.grid(True, which='major', color='k', axis='both', linestyle='-', linewidth=0.75, zorder=0)
            plt.grid(True, which='minor', color='r', axis='both', linestyle=':', linewidth=0.5, zorder=0)
            for spine in plt.gca().spines.values():
                spine.set_linewidth(2)
            # Enable minor ticks
            plt.minorticks_on()
            plt.savefig(f'Results/{ylable}.png', dpi=800)

        name1 = ['Accuracy', 'Sensitivity', 'Specificity', 'Precision', 'F_measure', 'MCC', 'NPV', 'FPR', 'FNR']
        hatches = ['/-', '**', '|.', 'xo', '+*', 'x', 'o', 'O', '.']  # Example hatch patterns

        marker_list =['>','v', '<', 'h', '*','^', 'p', 'H']
        for idx, jj in enumerate(indx):
            new_ = plot_result.loc[([80 ], [jj]), :]
            new_.reset_index(drop=True, level=1, inplace=True)
            print('\n',new_.to_markdown())
            new_.to_csv('Results/'+ jj + 'Graph.csv')
            # plt.rc('font', weight='bold')
            # ax = new_.plot(figsize=(10, 6), kind='bar', width=0.8, use_index=True, rot=0, color=custom_colors, edgecolor='black')
            # ax = new_.plot(figsize=(10, 6), marker=marker_list, linestyle='-', color=custom_colors, linewidth=2, markersize=15)
            # fig, ax = plt.subplots(figsize=(10, 6))
            # line_styles = [(0, (3, 5, 1, 5)), (0, (5, 10)),'-', '--', '-.', ':', '-', '--']

            data=new_.values.flatten()
            new = new_.values

            def square_plot(value, colors, ylab=None):
                labels = clmn
                from matplotlib.patches import Rectangle, Ellipse
                # Example data
                values = value.flatten()  # [0.91, 0.93, 0.94, 0.95, 0.96, 0.97, 0.985, 0.995]
                fig, ax = plt.subplots(figsize=(12, 6))
                width = 0.5
                ellipse_h = 0.003
                cap_height = 0.003
                for i, (v, c) in enumerate(zip(values, colors)):
                    # Cylinder body
                    ax.add_patch(Rectangle((i - width / 2, 0), width, v, facecolor=c, edgecolor='black', linewidth=1.5))
                    ax.add_patch(Ellipse((i, v), width, ellipse_h, facecolor=c, edgecolor='black', linewidth=1.5))
                    # # Value label
                    ax.text(i, v + 0.01, f'{v:.3f}', ha='center', fontsize=14, fontweight='bold')
                # Axis settings
                ax.set_xlim(-0.8, len(labels) - 0.2)
                if ylab=='fnr': ax.set_ylim(0, 0.5)
                elif ylab=='fpr': ax.set_ylim(0, 0.3)
                else:
                    ax.set_ylim(0.6, 1.1)
                ax.set_xticks(range(len(labels)))
                ax.set_xticklabels(labels, rotation=20, fontweight='bold', fontsize=14)
                ax.set_ylabel(ylab, fontsize=18, fontweight='bold')
                ax.grid(axis='y', linestyle='--', alpha=0.5)
                ax.set_facecolor("#f8f8f8")
                plt.tight_layout()
                plt.show(block=False)
                plt.savefig(f'Results/{ylab}.png', dpi=800)

            square_plot(new, custom_colors, jj)


            # x_positions = np.arange(len(data))

            # plt.figure(figsize=(12, 6))  # adjust figure size
            # for i, bar in enumerate(plt.bar(x_positions, data, width=0.5, edgecolor='black', color=custom_colors)):
            #     bar.set_hatch(hatches[i])  # Set the hatch pattern for each bar
            # # plt.bar(x_positions, data, width=0.7, edgecolor='black', color=custom_colors)  # Create the bar plot
            # plt.xticks(x_positions, clmn,rotation=30)  # Set x-axis labels
            # # plt.xlabel("Learning Rate", fontweight='bold')
            # plt.ylabel(name1[idx], fontweight='bold',size=16)
            # plt.subplots_adjust(bottom=0.25)
            # plt.savefig(f'Results/{name1[idx]}.png', dpi=800)


        plt.show()





